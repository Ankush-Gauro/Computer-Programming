/*
-----------------------------------------------------------------------------
 Author      : Ankush Gauro
 Email       : agauro@myseneca.ca
 Student Id  : 108593237
 Section     : ZCC
 Date		 : 2024-01-25
 I have done all the coding by myself and only copied the code that my professor provided to complete my workshops and assignments.
-----------------------------------------------------------------------------
 */

#include <iostream>
#include "StMark.h"
#include "file.h"
#include "graph.h"
using namespace std;
namespace seneca {


    bool printReport(const char* filename) {

        StMark m[MAX_NO_RECS];
        int recoreds = 0;
        int g[10];
        for (int i = 0; i < 10; i++) {
            g[i] = 0;
        }
        if (openFile(filename)) {
            recoreds = readMarks(m);

            for (int i = 0; i < recoreds - 1; i++) {
                for (int j = 0; j < recoreds - i - 1; j++) {
                    // Compare and swap if needed
                    if (m[j].mark < m[j + 1].mark) {
                        // Swap elements
                        swap(m[j], m[j + 1]);
                    }
                }
            }

            for (int i = 0; i < recoreds; i++) {

                if (m[i].mark >= 91 && m[i].mark <= 100)
                    g[0]++;
                if (m[i].mark >= 81 && m[i].mark <= 90)
                    g[1]++;
                if (m[i].mark >= 71 && m[i].mark <= 80)
                    g[2]++;
                if (m[i].mark >= 61 && m[i].mark <= 70)
                    g[3]++;
                if (m[i].mark >= 51 && m[i].mark <= 60)
                    g[4]++;
                if (m[i].mark >= 41 && m[i].mark <= 50)
                    g[5]++;
                if (m[i].mark >= 31 && m[i].mark <= 40)
                    g[6]++;
                if (m[i].mark >= 21 && m[i].mark <= 30)
                    g[7]++;
                if (m[i].mark >= 11 && m[i].mark <= 20)
                    g[8]++;
                if (m[i].mark >= 0 && m[i].mark <= 10)
                    g[9]++;
            }
            
            printGraph(g, 10, "Students' mark distribution-----------------------------------------------+ ");

            for (int i = 0; i < recoreds; i++) {

                if (i < 9) {
                    cout << (i + 1) << "   :";
                    cout.width(3);
                    if (i >= 4)
                        cout << " [" << m[i].mark << " ] ";
                    else
                        cout << " [" << m[i].mark << "] ";
                    cout.width(3);
                    cout << m[i].name;
                    cout.width(3);
                    cout << m[i].surname << endl;
                }

                else if (i >= 9 && i <= 98) {
                    cout << (i + 1) << "  :";
                    cout.width(3);
                    cout << "[" << m[i].mark << " ] ";
                    cout.width(3);
                    cout << m[i].name;
                    cout.width(3);
                    cout << m[i].surname << endl;
                }
                else
                {
                    cout << (i + 1) << " :";
                    cout.width(3);
                    if (m[i].mark < 10)
                        cout << "[" << m[i].mark << "  ] ";

                    else
                        cout << "[" << m[i].mark << " ] ";
                    cout.width(3);
                    cout << m[i].name;
                    cout.width(3);
                    cout << m[i].surname << endl;

                }
            }

            closeFile();


        }
        else {
            cout << "This should not happen!" << endl;
        }
        return 0;

    }
}