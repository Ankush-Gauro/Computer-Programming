/**
 * WEB222 – Assignment 04
 *
 * I declare that this assignment is my own work in accordance with
 * Seneca Academic Policy. No part of this assignment has been
 * copied manually or electronically from any other source
 * (including web sites) or distributed to other students.
 *
 * Please update the following with your information:
 *
 *      Name:       Ankush Gauro
 *      Student ID: 108593237
 *      Date:       March 07, 2024
 */

// All of our data is available on the global `window` object.
// Create local variables to work with it in this file.
const { artists, songs } = window;

// For debugging, display all of our data in the console. You can remove this later.
console.log({ artists, songs }, "App Data");

document.addEventListener("DOMContentLoaded", function () {
  const menu = document.querySelector("#menu");
  const selectedArtist = document.querySelector("#selected-artist");
  const songsTableBody = document.querySelector("#songs");

  function createArtistButtons() {
    artists.forEach((artist) => {
      const button = document.createElement("button");
      button.textContent = artist.name;

      button.addEventListener("click", function () {
        showSongsForArtist(artist);
      });
      menu.appendChild(button);
    });
  }

  function showSongsForArtist(artist) {
    selectedArtist.innerHTML = "";

    const artistInfo = document.createElement("span");

    artistInfo.innerHTML = `${artist.name} (${artist.urls
      .map((url) => createClickableLink(url.url, url.name))
      .join(", ")})`;

    selectedArtist.appendChild(artistInfo);

    songsTableBody.innerHTML = "";

    const artistSongs = songs.filter(
      (song) => song.artistId === artist.artistId && !song.flagged && !song.explicit
    );

    artistSongs.forEach((song) => {
      const row = document.createElement("tr");

      row.addEventListener("click", () => console.log(song));

      const nameTd = document.createElement("td");

      const namesLink = document.createElement("a");
      namesLink.href = song.url;
      namesLink.textContent = song.title;
      namesLink.artistInfo = artist.artistInfo;
      namesLink.target = "_blank";

      nameTd.appendChild(namesLink);

      const yearTd = document.createElement("td");
      yearTd.textContent = song.year;

      const durationTd = document.createElement("td");
      durationTd.textContent = formatDuration(song.duration);

      row.appendChild(nameTd);
      row.appendChild(yearTd);
      row.appendChild(durationTd);

      songsTableBody.appendChild(row);
    });
  }
  function formatDuration(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? "0" : ""}${remainingSeconds}`;
  }

  function createClickableLink(url, text) {
    return `<a href="${url}" target="_blank">${text}</a>`;
  }

  createArtistButtons();

  if (artists.length > 0) {
    showSongsForArtist(artists[0]);
  }
});
