#include "shipping.h"
#include "mapping.h"

#include <stdio.h>

int addShipmentToBestTruck(struct Truck* trucks, const struct Map* map, const struct Shipment* shipment, const int numOfTrucks)
{
    if (!trucks || !map || !shipment || numOfTrucks < 1)
        return -1;

    int bestTruckIndex = findTruckForShipment(trucks, map, shipment, numOfTrucks);

    if (bestTruckIndex >= 0)
        addShipmentToTruck(&trucks[bestTruckIndex], shipment);

    return bestTruckIndex;
}

int findTruckForShipment(const struct Truck* trucks, const struct Map* map, const struct Shipment* shipment, const int numOfTrucks)
{
    if (!trucks || !map || !shipment || numOfTrucks < 1)
        return -1;

    struct Point orgin = { 0, 0 };
    struct Route route = getPossibleMoves(map, shipment->destination, orgin);

    if (!route.numPoints)
        return -1;

    if (shipment->destination.row > map->numRows || shipment->destination.col > map->numCols)
        return -1;

    int bestTruckIndex = -1;

    for (int i = 0; i < numOfTrucks; i++) {
        if (!hasTruckRoomForShipment(&trucks[i], shipment))
            continue;

        if (bestTruckIndex < 0)
            bestTruckIndex = i;

        int best = compareTrucksForShipment(&trucks[i], &trucks[bestTruckIndex], map, shipment);
        if (best > 0)
            bestTruckIndex = i;
    }

    return bestTruckIndex;
}

int hasTruckRoomForShipment(const struct Truck* truck, const struct Shipment* shipment)
{
    if (!truck || !shipment)
        return 0;

    return (truck->weightInKGs >= shipment->weightInKGs) && (truck->volumeInCuMs >= shipment->volumeInCuMs);
}

int compareTrucksForShipment(const struct Truck* left, const struct Truck* right, const struct Map* map, const struct Shipment* shipment)
{
    if (!left || !right || !map || !shipment)
        return 0;

    if (!hasTruckRoomForShipment(left, shipment) && !hasTruckRoomForShipment(right, shipment))
        return 0;

    struct Point leftClosest = left->route.points[getClosestPoint(&left->route, shipment->destination)];
    struct Point rightClosest = right->route.points[getClosestPoint(&right->route, shipment->destination)];
    struct Route leftDiversion = shortestPath(map, leftClosest, shipment->destination);
    struct Route rightDiversion = shortestPath(map, rightClosest, shipment->destination);
    int leftLimitingFactor = calculateLimitingFactor(left);
    int rightLimitingFactor = calculateLimitingFactor(right);

    if (leftDiversion.numPoints == rightDiversion.numPoints) {
        if (leftLimitingFactor > rightLimitingFactor)
            return 1;
        if (leftLimitingFactor < rightLimitingFactor)
            return -1;
        else
            return 0;
    }

    if (leftDiversion.numPoints < rightDiversion.numPoints)
        return 1;
    else
        return -1;

    return 0;
}

int calculateLimitingFactor(const struct Truck* truck)
{
    if (!truck)
        return 0;

    int weightFactor = (truck->weightInKGs * 100) / MAX_WEIGHT_IN_KGS;
    int volumeFactor = (truck->volumeInCuMs * 100) / MAX_VOLUME_IN_CU_M;

    return (weightFactor > volumeFactor) ? weightFactor : volumeFactor;
}

void addShipmentToTruck(struct Truck* truck, const struct Shipment* shipment)
{
    if (!truck || !shipment)
        return;

    if (hasTruckRoomForShipment(truck, shipment)) {
        truck->weightInKGs -= shipment->weightInKGs;
        truck->volumeInCuMs -= shipment->volumeInCuMs;
    }
}

void printTruckPath(const struct Truck* truck, const struct Map* map, const struct Shipment* shipment)
{
    printf("Ship on ");

    switch (truck->route.routeSymbol) {
    case 2:
        printf("BLUE");
        break;
    case 4:
        printf("GREEN");
        break;
    case 8:
        printf("YELLOW");
        break;
    }

    printf(" LINE, ");

    int closestPoint = getClosestPoint(&truck->route, shipment->destination);
    struct Route diversion = shortestPath(map, truck->route.points[closestPoint], shipment->destination);

    if (!diversion.numPoints) {
        printf("no diversion\n");
        return;
    }

    printf("divert: ");

    for (int i = 0; i < diversion.numPoints; i++) {
        printf("%d%c", diversion.points[i].row + 1, diversion.points[i].col + 'A');
        if (i != diversion.numPoints - 1)
            printf(", ");
    }

    putchar('\n');
}