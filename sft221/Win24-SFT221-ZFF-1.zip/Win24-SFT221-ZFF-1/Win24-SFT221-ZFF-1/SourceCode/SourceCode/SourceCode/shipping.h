#pragma once
#ifndef SHIPMENT_H
#define SHIPMNET_H

#include "mapping.h"
#define MAX_WEIGHT_IN_KGS 1200
#define MAX_VOLUME_IN_CU_M 50

struct Shipment {
	struct Point destination;
	double weightInKGs;
	double volumeInCuMs;
};

struct Truck {
	struct Route route;
	double weightInKGs;
	double volumeInCuMs;
};

/*
trucks -> An array of trucks
map -> The map with the buildings
shipment -> The shipment to be assigned
numOfTrucks The number of trucks in the array

Should return the index of best truck

*/
int addShipmentToBestTruck(struct Truck* trucks, const struct Map* map, const struct Shipment* shipment, const int numOfTrucks);

/*
  Adds a shipment to a specific truck.
  The function subtracts the shipment's weight and volume from the truck's available weight and volume.

   truck     The truck to which the shipment should be added.
   shipment  The shipment to be added to the truck.
 */
void addShipmentToTruck(struct Truck* truck, const struct Shipment* shipment);

/**
 * Finds the best suitable truck for a shipment from the given list of trucks.
 trucks      An array of trucks to consider for the shipment.
 map         The map with the buildings on it.
 shipment    The shipment to be assigned to a truck.
 numOfTrucks The number of trucks in the array.
 returns           The index of the best truck, or -1 if no suitable truck is found.
 */
int findTruckForShipment(const struct Truck* trucks, const struct Map* map, const struct Shipment* shipment, const int numOfTrucks);

/**
 * Compares two trucks to determine their suitability for a shipment.
left        Pointer to the left truck for comparison.
right       Pointer to the right truck for comparison.
map         The map with the buildings on it.
shipment    The shipment to be assigned to a truck.
returns           A value indicating the comparison result, Positive value if the left truck is better suited for the shipment, Negative value if the right truck is better suited for the shipment, Zero if the trucks are considered equal.
 */
int compareTrucksForShipment(const struct Truck* left, const struct Truck* right, const struct Map* map, const struct Shipment* shipment);

/**
 * Checks if a truck has enough room to accommodate a shipment.

  truck     The truck to check for room.
  shipment  The shipment to be assigned to a truck.
  returns         True if the truck has enough room, false otherwise.
 */
int hasTruckRoomForShipment(const struct Truck* truck, const struct Shipment* shipment);

/**
 * Calculates the limiting factor of a truck for a given shipment.

 truck     The truck for which to calculate the limiting factor.
 returns         The limiting factor as a percentage.
 */
int calculateLimitingFactor(const struct Truck* truck);

/**
 * Prints the path or route information of a truck.

 truck     The truck for which to print the path.
 map       The map with the buildings on it.
 shipment  The shipment to be added to the truck.
 */
void printTruckPath(const struct Truck* truck, const struct Map* map, const struct Shipment* shipment);


#endif
