#define _CRT_SECURE_NO_WARNINGS

#include "application.h"
#include "mapping.h"
#include "shipping.h"

#include <stdio.h>

void header()
{
    printf("=================\n"
           "Seneca Deliveries\n"
           "=================\n");
}

void footer()
{
    printf("Thanks for shipping with Seneca!\n");
}

void printErrorCode(int errorCode)
{
    switch (errorCode) {
    case 2:
        printf("Invalid destination\n");
        break;
    case 3:
        printf("Invalid weight (must be 1-1000 Kg.)\n");
        break;
    case 4:
        printf("Invalid size\n");
    }
}

int processInput(const struct Shipment* shipment, const struct Map* map)
{
    if (!shipment)
        return 1;

    if (shipment->destination.row > map->numRows || shipment->destination.col > map->numCols)
        return 2;

    struct Point origin = { 0, 0 };
    struct Route route = getPossibleMoves(map, shipment->destination, origin);

    if (!route.numPoints)
        return 2;

    if (shipment->weightInKGs < 1 || shipment->weightInKGs > MAX_WEIGHT_IN_KGS)
        return 3;

    if (shipment->volumeInCuMs != 0.25 && shipment->volumeInCuMs != 0.50 && shipment->volumeInCuMs != 1.00)
        return 4;

    return 0;
}


void run()
{
    struct Map map = populateMap();
    struct Truck trucks[] = {
        { getBlueRoute(), MAX_WEIGHT_IN_KGS, MAX_VOLUME_IN_CU_M },
        { getGreenRoute(), MAX_WEIGHT_IN_KGS, MAX_VOLUME_IN_CU_M },
        { getYellowRoute(), MAX_WEIGHT_IN_KGS, MAX_VOLUME_IN_CU_M },
    };

    double shipmentWeight = 0;
    double shipmentVolume = 0;
    struct Point destination = { 0, 0 };

    header();

    while (true) {
        printf("Enter shipment weight, box size and destination (0 0 x to stop): ");
        scanf("%lf %lf", &shipmentWeight, &shipmentVolume);

        if (!shipmentWeight && !shipmentVolume)
            break;

        scanf(" %d%c%*c", (int*)&destination.row, &destination.col);

        const struct Shipment currentShipment = {
            { destination.row - 1, destination.col - 'A' },
            shipmentWeight,
            shipmentVolume
        };

        int errorCode = processInput(&currentShipment, &map);

        if (errorCode) {
            printErrorCode(errorCode);
            continue;
        }

        int truckIndex = addShipmentToBestTruck(trucks, &map, &currentShipment, 3);

        printTruckPath(&trucks[truckIndex], &map, &currentShipment);
    }

    footer();
}