#ifndef APPLICATION_H
#define APPLICATION_H

#include <stdbool.h>
#include "shipping.h"

/*
Displays the header for the shipping application.
 */
void header();

/*
Displays the footer message for the shipping application.
 */
void footer();

/*
Prints an error message based on the given error code
 */
void printErrorCode(int errorCode);

/*
Processes the input
 */
int processInput(const struct Shipment* shipment, const struct Map* map);

/*
The main function that runs the shipping application
 */
void run();

#endif // !APPLICATION_H
