

#include "pch.h"
#include "CppUnitTest.h"

extern "C" {
#include "../SourceCode/mapping.h"
#include "../SourceCode/shipping.h"
}

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest
{
    TEST_CLASS(BlackBoxTest_findTruckForShipmentTests)
    {
    public:

        // 19. Tests with empty array of trucks
        TEST_METHOD(FindTruckForShipment_EmptyTrucksList) {
            int numOfTrucks = 0;
            struct Truck trucks[1] = { { 0, 0, 0 } };

            struct Map map = populateMap();
            struct Shipment shipment = { { 7, 11 }, 112, 6 };

            int result = findTruckForShipment(trucks, &map, &shipment, numOfTrucks);

            Assert::AreEqual(-1, result);
        }

        // 20. Tests with a shipment that has 0 value in weight and volume.
        TEST_METHOD(FindTruckForShipment_ShipmentWithZeroWeightAndVolume) {
            int numOfTrucks = 2;
            struct Truck trucks[2] = {
               { {getBlueRoute()}, 150, 3},
              { {getGreenRoute()}, 250, 10}
            };

            struct Map map = populateMap();
            struct Shipment shipment = { { 7, 11 }, 0, 0 };

            int result = findTruckForShipment(trucks, &map, &shipment, numOfTrucks);

            Assert::IsTrue(result == 0 || result == 1);
        }


        // 21. Tests with trucks that have the same capacities 
        TEST_METHOD(FindTruckForShipment_MultipleTrucksWithSameCapacities) {
            int numOfTrucks = 2;
            struct Truck trucks[2] = {
                { getBlueRoute(), 150, 10 },
                { getGreenRoute(), 150, 10 }
            };

            struct Map map = populateMap();
            struct Shipment shipment = { { 7, 11 }, 112, 5 };

            int result = findTruckForShipment(trucks, &map, &shipment, numOfTrucks);

            Assert::IsTrue(result == 0 || result == 1);
        }


        //22. Tests with multiple trucks having the same capactities but different paths
        TEST_METHOD(FindTruckForShipment_MultipleTrucksWithEqualCapacityButDifferentPaths) {
            int numOfTrucks = 3;
            struct Truck trucks[3] = {
               { {getBlueRoute()}, 150, 10},
               { {getGreenRoute()}, 150, 10},
               { {getYellowRoute()}, 150, 10}
            };

            struct Map map = populateMap();
            struct Shipment shipment = { { 10, 8 }, 112, 6 };

            int result = findTruckForShipment(trucks, &map, &shipment, numOfTrucks);

            Assert::IsTrue(result >= 0 && result < numOfTrucks, L"The returned truck index should be valid.");
        }
        // 23.Tests with one truck that does not have enough capacity
        TEST_METHOD(FindTruckForShipment_OneTruckWithInsufficientCapacity) {
            int numOfTrucks = 1;
            struct Truck trucks[1] = { { getBlueRoute(), 120, 8 } };

            struct Map map = populateMap();
            struct Shipment shipment = { { 7, 11 }, 150, 10 };

            int result = findTruckForShipment(trucks, &map, &shipment, numOfTrucks);

            Assert::AreEqual(-1, result);
        }


    };


    TEST_CLASS(WhiteBoxTests_FindTruckForShipmentTests) {
public:
    // 1. Tests with empty array of trucks
    TEST_METHOD(FindTruckForShipment_EmptyTrucksList) {
        int numOfTrucks = 0;
        struct Truck trucks[1] = { { getBlueRoute(), 0, 0 } };

        struct Map map = populateMap();
        struct Shipment shipment = { { 7, 11 }, 112, 6 };

        int result = findTruckForShipment(trucks, &map, &shipment, numOfTrucks);

        Assert::AreEqual(-1, result);
    }

    // 2. Tests with a shipment that has 0 value in weight and volume
    TEST_METHOD(FindTruckForShipment_ShipmentWithZeroWeightAndVolume) {
        int numOfTrucks = 2;
        struct Truck trucks[2] = {
            { getBlueRoute(), 150, 3 },
            { getGreenRoute(), 250, 10 }
        };

        struct Map map = populateMap();
        struct Shipment shipment = { { 7, 11 }, 0, 0 };

        int result = findTruckForShipment(trucks, &map, &shipment, numOfTrucks);

        Assert::IsTrue(result == 0 || result == 1);
    }

    // 3. Tests with trucks that have the same capacities 
    TEST_METHOD(FindTruckForShipment_MultipleTrucksWithEqualCapacities) {
        int numOfTrucks = 2;
        struct Truck trucks[2] = {
            { getBlueRoute(), 150, 10 },
            { getGreenRoute(), 150, 10 }
        };

        struct Map map = populateMap();
        struct Shipment shipment = { { 7, 11 }, 112, 6 };

        int result = findTruckForShipment(trucks, &map, &shipment, numOfTrucks);

        Assert::IsTrue(result == 0 || result == 1);
    }


    // 4. Tests with multiple trucks having different capacities
    TEST_METHOD(FindTruckForShipment_MultipleTrucksWithDifferentCapacities) {
        int numOfTrucks = 3;
        struct Truck trucks[3] = {
            { getBlueRoute(), 100, 25 },
            { getGreenRoute(), 120, 50 },
            { getBlueRoute(), 250, 40 }
        };

        struct Map map = populateMap();
        struct Shipment shipment = { { 10, 8 }, 200, 30 };

        int result = findTruckForShipment(trucks, &map, &shipment, numOfTrucks);

        Assert::AreEqual(1, result);
    }



    };
}



