#include "pch.h"
#include "CppUnitTest.h"

extern "C" {
#include "../SourceCode/mapping.h"
#include "../SourceCode/shipping.h"
}

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest
{
	TEST_CLASS(BlackBoxTest_CalculateLimitngFactorTests)
	{
	public:

		// 14. Testing with truck that has max weight and volume
		TEST_METHOD(CalculateLimitingFactor_MaxWeightAndVolume)
		{
			struct Truck truck = { { 0 }, 1200, 50 };

			int result = calculateLimitingFactor(&truck);

			Assert::AreEqual(100, result);
		}


		// 15.  Testing with truck that has the weight as the limiting factor
		TEST_METHOD(CalculateLimitingFactor_TruckWeightLimiting)
		{
			struct Truck truck = { { 0 }, 1250, 30 };

			int result = calculateLimitingFactor(&truck);

			Assert::AreEqual(104, result);
		}

		// 16. Testing with truck that has the volume as the limiting factor
		TEST_METHOD(CalculateLimitingFactor_TruckVolumeLimiting)
		{
			struct Truck truck = { { 0 }, 800, 70 };

			int result = calculateLimitingFactor(&truck);

			Assert::AreEqual(140, result);
		}




		//17.  Testing with truck that has max volume but less weight
		TEST_METHOD(CalculateLimitingFactor_MaxVolumeButLesserWeight)
		{
			struct Truck truck = { { 0 }, 1000, 50 };

			int result = calculateLimitingFactor(&truck);

			Assert::AreEqual(100, result);
		}

		// 18. Testing with truck that has 0 weight and volume
		TEST_METHOD(CalculateLimitingFactor_ZeroTruckWeightAndVolume) {
			struct Truck truck = { { 0 }, 0, 0 };

			int result = calculateLimitingFactor(&truck);

			Assert::AreEqual(0, result);
		}

	};

	TEST_CLASS(WhiteBoxTests_CalculateLimitingFactorTests) {
public:

	// 1 Testing with truck that has max weight and volume
	TEST_METHOD(CalculateLimitingFactor_MaxWeightAndVolume)
	{
		struct Truck truck = { { 0 }, 1200, 50 };

		int result = calculateLimitingFactor(&truck);

		Assert::AreEqual(100, result);
	}

	// 2. Testing with truck that has the weight as the limiting factor
	TEST_METHOD(CalculateLimitingFactor_TruckWeightLimiting)
	{
		struct Truck truck = { { 0 }, 1000, 20 };

		int result = calculateLimitingFactor(&truck);

		Assert::AreEqual(83, result);
	}


	// 3. Testing with an empty truck (NULL value)
	TEST_METHOD(CalculateLimitingFactor_NullInput)
	{
		int result = calculateLimitingFactor(NULL);

		Assert::AreEqual(0, result);
	}




	// 4. Testing with truck where volume is the limiting factor
	TEST_METHOD(CalculateLimitingFactor_TruckVolumeLimiting)
	{
		struct Truck truck = { { 0 }, 120, 40 };

		int result = calculateLimitingFactor(&truck);

		Assert::AreEqual(80, result);
	}


	};
}
