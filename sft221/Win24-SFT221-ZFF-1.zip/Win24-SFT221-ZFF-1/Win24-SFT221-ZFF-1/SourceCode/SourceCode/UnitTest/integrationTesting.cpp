#include "pch.h"
#include "CppUnitTest.h"

extern "C" {
#include "../SourceCode/mapping.h"
#include "../SourceCode/shipping.h"
}

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
namespace UnitTest {
	TEST_CLASS(IntegrationTests) {
public:
    // 1. Integrated Testing for hasTruckRoomForShipment and addShipmentToBestTruck    
     TEST_METHOD(integratedTestingHasRoomForShipment_AddShipmentToBestTruck) {
        struct Shipment shipment = { { 7, 7 }, 10, 8 };
        struct Truck truck = { getBlueRoute(), 110, 25 };

        int hasRoom = hasTruckRoomForShipment(&truck, &shipment);

        addShipmentToTruck(&truck, &shipment);
        int hasRoom1 = hasTruckRoomForShipment(&truck, &shipment);

        Assert::IsTrue(hasRoom);
        Assert::IsFalse(hasRoom1);
    }


     // 2. Integrated Testing for hasTruckRoomForShipment and CompateTrucksForShipment
  
    TEST_METHOD(integratedTestingHasTruckRoomForshipment_CompareTruckForShipment)
    {
        struct Map map = populateMap();
        struct Shipment shipment = { { 7, 11 }, 110, 6 };
        struct Truck trucks[] = {
            { getBlueRoute(), 100, 20 },
            { getGreenRoute(), 150, 30 },
            { getYellowRoute(), 350, 35 }
        };

        int hasRoom1 = hasTruckRoomForShipment(&trucks[0], &shipment);
        int hasRoom2 = hasTruckRoomForShipment(&trucks[1], &shipment);
      

        int compareResult1 = compareTrucksForShipment(&trucks[0], &trucks[1], &map, &shipment);
        int compareResult2 = compareTrucksForShipment(&trucks[1], &trucks[2], &map, &shipment);

       
        Assert::IsTrue(hasRoom1);
        Assert::IsFalse(hasRoom2);
        Assert::AreEqual(-1, compareResult1);
        Assert::AreEqual(1, compareResult2);
    }

	};

}