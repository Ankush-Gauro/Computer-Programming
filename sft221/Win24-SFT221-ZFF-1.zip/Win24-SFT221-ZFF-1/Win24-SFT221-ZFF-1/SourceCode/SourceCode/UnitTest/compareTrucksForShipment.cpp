#include "pch.h"
#include "CppUnitTest.h"

extern "C" {
#include "../SourceCode/mapping.h"
#include "../SourceCode/shipping.h"
}

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest
{
    TEST_CLASS(BlackBoxTest_CompareTrucksForShipmentTests)
    {
    public:

        // 6. testing with two trucks with different limiting factors and diversions.
        TEST_METHOD(TrucksWithDifferentLimitingFactorsAndDiversions) {
            struct Map TestMap = populateMap();
            struct Truck leftTruck = { getBlueRoute(), 110, 35 };
            struct Truck rightTruck = { getGreenRoute(), 110, 35 };
            struct Shipment shipments = { { 7, 13 }, 60, 20 };

            int result = compareTrucksForShipment(&leftTruck, &rightTruck, &TestMap, &shipments);

            Assert::IsTrue(result < 0);
        }

        //7.  Testing with two trucks with same limiting factors and diversions. 
        TEST_METHOD(TrucksWithSameLimitingFactorsAndDiversions) {
            struct Map TestMap = populateMap();
            struct Truck leftTruck = { getBlueRoute(), 110, 35 };
            struct Truck rightTruck = { getGreenRoute(), 110, 35 };
            struct Shipment shipments = { { 9, 13 }, 55, 10 };

            int result = compareTrucksForShipment(&leftTruck, &rightTruck, &TestMap, &shipments);

            Assert::IsFalse(result < 0);
        }

        // 8. Testing with two trucks with not enough capacity for shipment
        TEST_METHOD(TrucksWithInsufficientCapacity) {
            struct Map TestMap = populateMap();
            struct Truck leftTruck = { getBlueRoute(), 110, 35 };
            struct Truck rightTruck = { getGreenRoute(), 110, 35 };
            struct Shipment shipments = { { 7, 13 }, 120, 25 };

            int result = compareTrucksForShipment(&leftTruck, &rightTruck, &TestMap, &shipments);

            Assert::IsTrue(result == 0);
        }


    };

    TEST_CLASS(WhiteBox_CompareTrucksForShipmentTests) {
public:

    // 1. Testing with input values for right truck being NULL
    TEST_METHOD(AnyOfInputPointerIsNull) {
        struct Map TestMap = populateMap();
        struct Truck* leftTruck = NULL;
        struct Truck rightTruck = { getGreenRoute(), 110, 35 };
        struct Shipment shipments = { { 7, 13 }, 60, 20 };

        int result = compareTrucksForShipment(leftTruck, &rightTruck, &TestMap, &shipments);

        Assert::AreEqual(0, result);
    }

    // 2. Testing with two trucks with different limit factors (right > left)
    TEST_METHOD(TrucksWithSameDiversionAndDifferentLimitingFactor) {
        struct Map TestMap = populateMap();
        struct Truck leftTruck = { getBlueRoute(), 110, 35 };
        struct Truck rightTruck = { getGreenRoute(), 310, 45 };
        struct Shipment shipments = { { 9, 13 }, 55, 10 };

        int result = compareTrucksForShipment(&leftTruck, &rightTruck, &TestMap, &shipments);

        Assert::AreEqual(1, result);
    }

    // 3. Testing with two trucks with not enough capacity (weight) for shipment
    TEST_METHOD(NotEnoughWeightCapacity) {
        struct Map TestMap = populateMap();
        struct Truck leftTruck = { getGreenRoute(), 110, 35 };
        struct Truck rightTruck = { getGreenRoute(), 110, 35 };
        struct Shipment shipments = { { 7, 13 }, 120, 25 };

        int result = compareTrucksForShipment(&leftTruck, &rightTruck, &TestMap, &shipments);

        Assert::AreEqual(0, result);
    }

    // 4. Testing with two trucks with same values and limiting factors
    TEST_METHOD(SameDiversionSameLimitingFactor) {
        struct Map TestMap = populateMap();
        struct Truck leftTruck = { getGreenRoute(), 110, 35 };
        struct Truck rightTruck = { getGreenRoute(), 110, 35 };
        struct Shipment shipments = { { 4, 17 }, 55, 9 };

        int result = compareTrucksForShipment(&leftTruck, &rightTruck, &TestMap, &shipments);

        Assert::AreEqual(0, result);
    }

    };
}
