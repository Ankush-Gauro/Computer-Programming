#include "pch.h"
#include "CppUnitTest.h"

extern "C" {
#include "../SourceCode/mapping.h"
#include "../SourceCode/shipping.h"
}

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest
{
    TEST_CLASS(BlackBoxTest_HasTruckRoomForShipmentTests)
    {
    public:

        // 1.Testing with empty truck and shipment
        TEST_METHOD(TestHasTruckRoomForShipment_EmptyTruckAndEmptyShipment) {
            struct Truck truck = { 0 };
            struct Shipment shipment = { 0 };
            Assert::IsTrue(hasTruckRoomForShipment(&truck, &shipment));
        }


        //2.  Testing with truck and shipment capacity matching
        TEST_METHOD(TestHasTruckRoomForShipment_TruckCapacityExactlyMatched) {
            struct Truck truck = { { 0 }, 800, 50 };
            struct Shipment shipment = { { 5, 5 }, 800, 50 };
            Assert::IsTrue(hasTruckRoomForShipment(&truck, &shipment));
        }


        // 3. Testing with an empty truck and non-empty shipment
        TEST_METHOD(TestHasTruckRoomForShipment_EmptyTruckAndNonEmptyShipment) {
            struct Truck truck = { { 0 }, 0, 0 };
            struct Shipment shipment = { { 5, 5 }, 800, 50 };
            Assert::IsFalse(hasTruckRoomForShipment(&truck, &shipment));
        }

        // 4.  Testing with a non-empty truck and an empty shipment
        TEST_METHOD(TestHasTruckRoomForShipment_NonEmptyTruckAndEmptyShipment) {
            struct Truck truck = { { 0 }, 800, 50 };
            struct Shipment shipment = { 0 };
            Assert::IsTrue(hasTruckRoomForShipment(&truck, &shipment));
        }


        // 5. Testing with a shipment that exceeds truck volume limit
        TEST_METHOD(TestHasTruckRoomForShipment_TruckVolumeLimitExceeded) {
            struct Truck truck = { { 0 }, 550, 40 };
            struct Shipment shipment = { { 5, 5 }, 150, 55 };
            Assert::IsFalse(hasTruckRoomForShipment(&truck, &shipment));
        }


    };


    TEST_CLASS(WhiteBoxTests_HasTruckRoomForShipmentTests) {
public:

    // 1. Testing with empty truck and shipment (NULL input)
    TEST_METHOD(HasTruckRoomForShipment_NullShipment) {
        struct Map map = populateMap();
        struct Truck truck1 = { { 0 }, 100, 8 };

        bool result = hasTruckRoomForShipment(&truck1, nullptr);

        Assert::IsFalse(result);
    }

    // 2. Testing with truck and shipment capacity matching
    TEST_METHOD(HasTruckRoomForShipment_ExactWeightAndVolume) {
        struct Map map = populateMap();
        struct Shipment shipment2 = { { 9, 9 }, 500, 40 };
        struct Truck truck2 = { { 0 }, 500, 40 };

        bool result = hasTruckRoomForShipment(&truck2, &shipment2);

        Assert::IsTrue(result);
    }
    // 3. Testing with truck that has enough capacity for shipment
    TEST_METHOD(HasTruckRoomForShipment_ValidInput) {
        struct Map map = populateMap();
        struct Shipment shipment3 = { { 8, 8 }, 650, 25 };
        struct Truck truck3 = { { 0 }, 800, 50 };

        bool result = hasTruckRoomForShipment(&truck3, &shipment3);

        Assert::IsTrue(result);
    }



    // 4. Testing with truck that does not have enough capacity (weight) for shipment
    TEST_METHOD(HasTruckRoomForShipment_InsufficientWeight) {
        struct Map map = populateMap();
        struct Shipment shipment4 = { { 7, 7 }, 650, 40 };
        struct Truck truck4 = { { 0 }, 500, 45 };

        bool result = hasTruckRoomForShipment(&truck4, &shipment4);

        Assert::IsFalse(result);
    }




    };
}
