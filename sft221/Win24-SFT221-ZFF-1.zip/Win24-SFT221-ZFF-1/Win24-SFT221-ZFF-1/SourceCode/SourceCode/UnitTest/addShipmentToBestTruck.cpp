#include "pch.h"
#include "CppUnitTest.h"

extern "C" {
#include "../SourceCode/mapping.h"
#include "../SourceCode/shipping.h"
}

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest
{
	TEST_CLASS(BlackBoxTest_AddShipmentToBestTruckTests)
	{
	public:

		// 1. Testing with valid inputs for all parameters, assuming Blue truck is the best based on visual map
		TEST_METHOD(TestAddShipmentToBestTruck_ValidInputs) {
			struct Truck trucks[] = {
				{ getBlueRoute(), 100, 10 },
				{ getGreenRoute(), 150, 15 },
				{ getYellowRoute(), 200, 20 }
			};
			int numOfTrucks = 3;

			struct Map map = populateMap();
			struct Shipment shipment = { { 7, 6 }, 10, 2 };

			int result = addShipmentToBestTruck(trucks, &map, &shipment, numOfTrucks);

			Assert::AreNotEqual(1, result);
		}

		// 2. Testing with an empty list of truck
		TEST_METHOD(TestAddShipmentToBestTruck_EmptyListOfTruck) {
			struct Truck* trucks = NULL;
			int numOfTrucks = 0;

			struct Map map = populateMap();
			struct Shipment shipment = { { 7, 6 }, 10, 2 };

			int result = addShipmentToBestTruck(trucks, &map, &shipment, numOfTrucks);

			Assert::AreEqual(-1, result);
		}



		// 3.  Testing with negative truck count
		TEST_METHOD(TestAddShipmentToBestTruck_NegativeTruckCount) {
			struct Truck trucks[] = {
				{ getBlueRoute(), 100, 10 },
				{ getGreenRoute(), 150, 15 },
				{ getYellowRoute(), 200, 20 }
			};
			int numOfTrucks = -1;

			struct Map map = populateMap();
			struct Shipment shipment = { { 7, 6 }, 10, 2 };

			int result = addShipmentToBestTruck(trucks, &map, &shipment, numOfTrucks);

			Assert::AreEqual(-1, result);
		}


		// 4. Testing with null value for map and shipment parameters
		TEST_METHOD(TestAddShipmentToBestTruck_NullValue) {
			struct Truck trucks[] = {
				{ getBlueRoute(), 100, 10 },
				{ getGreenRoute(), 150, 15 },
				{ getYellowRoute(), 200, 20 }
			};
			int numOfTrucks = 3;

			int result = addShipmentToBestTruck(trucks, NULL, NULL, numOfTrucks);

			Assert::AreEqual(-1, result);
		}


		// 5. Testing with a destination outside of the map boundaries

		
		TEST_METHOD(TestAddShipmentToBestTruck_DestinationOutsideOfMapBoundaries) {
			struct Truck trucks[] = {
				{ getBlueRoute(), 100, 10 },
				{ getGreenRoute(), 150, 15 },
				{ getYellowRoute(), 200, 20 }
			};
			int numOfTrucks = 3;

			struct Map map = populateMap();
			struct Shipment shipment = { { 120, 110 }, 10, 2 };

			int result = addShipmentToBestTruck(trucks, &map, &shipment, numOfTrucks);

			Assert::AreEqual(1, result);
		} 
	};
	

	TEST_CLASS(WhiteBoxTest_AddShipmentToBestTruckTests) {
public:


	// 1. Testing for a negative numOfTrucks provided
	TEST_METHOD(TestAddShipmentToBestTruck_NegativeNumberOfTrucks) {
		struct Map map = populateMap();
		struct Shipment shipment = { { 7, 6 }, 10, 2 };
		struct Truck trucks[] = {
			{ getBlueRoute(), 100, 10 },
			{ getGreenRoute(), 150, 15 },
			{ getYellowRoute(), 200, 20 }
		};
		int numOfTrucks = -1;

		int result = addShipmentToBestTruck(trucks, &map, &shipment, numOfTrucks);

		Assert::AreEqual(-1, result);
	}

	// 2. Testing with a truck that has 0 capacity
	TEST_METHOD(TestAddShipmentToBestTruck_EmptyTruck) {
		struct Map map = populateMap();
		struct Shipment shipment = { { 7, 6 }, 140, 15 };
		struct Truck truck = { getBlueRoute(), 0, 0 };

		int result = addShipmentToBestTruck(&truck, &map, &shipment, 1);

		Assert::AreEqual(-1, result);
	}

	// 3. Testing with shipment volume that is higher than truck's capacity
	TEST_METHOD(TestAddShipmentToBestTruck_ExceedsVolumeCapacityOfAllTrucks) {
		struct Map map = populateMap();
		struct Shipment shipment = { { 7, 6 }, 80, 50 };
		struct Truck trucks[] = {
			{ getBlueRoute(), 100, 10 },
			{ getGreenRoute(), 150, 15 },
			{ getYellowRoute(), 200, 20 }
		};
		int numOfTrucks = 3;

		int result = addShipmentToBestTruck(trucks, &map, &shipment, numOfTrucks);

		Assert::AreEqual(-1, result);
	}



	// 4. Testing with shipment weight that is higher than truck's capacity
	TEST_METHOD(TestAddShipmentToBestTruck_ExceedsWeightCapacityOfAllTrucks) {
		struct Map map = populateMap();
		struct Shipment shipment = { { 5, 5 }, 600, 20 };
		struct Truck trucks[] = {
			{ getBlueRoute(), 100, 10 },
			{ getGreenRoute(), 150, 15 },
			{ getYellowRoute(), 200, 20 }
		};
		int numOfTrucks = 3;

		int result = addShipmentToBestTruck(trucks, &map, &shipment, numOfTrucks);

		Assert::AreEqual(-1, result);
	}



	};


}
