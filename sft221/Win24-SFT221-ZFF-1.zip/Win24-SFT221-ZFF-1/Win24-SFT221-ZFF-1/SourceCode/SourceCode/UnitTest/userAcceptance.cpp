#include "CppUnitTest.h"

extern "C" {
#include "../SourceCode/application.h"
#include "../SourceCode/mapping.h"
#include "../SourceCode/shipping.h"
}

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest {

    TEST_CLASS(ProcessInputTests)
    {
    public:
        // Test case: Invalid destination
        TEST_METHOD(TestInvalidDestination)
        {
            struct Shipment shipment = { { 30, 3 }, 50, 0.5 };
            struct Map map = populateMap();

            int errorCode = processInput(&shipment, &map);

            Assert::AreEqual(2, errorCode);
        }

        // Test case: Invalid weight
        TEST_METHOD(TestInvalidWeight)
        {
            struct Shipment shipment = { { 12, 1 }, 1300, 0.5 };
            struct Map map = populateMap();

            int errorCode = processInput(&shipment, &map);

            Assert::AreEqual(3, errorCode);
        }

        // Test case: Invalid volume
        TEST_METHOD(TestInvalidVolume)
        {
            struct Shipment shipment = { { 12, 1 }, 50, 10.0 };
            struct Map map = populateMap();

            int errorCode = processInput(&shipment, &map);

            Assert::AreEqual(4, errorCode);
        }
    };
}